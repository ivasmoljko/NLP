treniranje = open("korpus.txt", "r",encoding="utf8").read()
def klasificiranje(treniranje):
    f_Leonard= open("Leonard.txt","w+")
    f_Penny= open("Penny.txt","w+")
    f_Sheldon= open("Sheldon.txt","w+")
    f_Howard=open("Howard.txt","w+")
    for i in range(len(treniranje)):
        if treniranje[i:i+8]=="Leonard:":
            j=treniranje[i+8:].find("\n")
            f_Leonard.write(treniranje[i+8:j+i+8]+"\n")
        if treniranje[i:i+8]=="Sheldon:":
            j = treniranje[i + 8:].find("\n")
            f_Sheldon.write(treniranje[i + 8:j + i + 8]+"\n")
        if treniranje[i:i+6]=="Penny:":
            j = treniranje[i + 6:].find("\n")
            f_Penny.write(treniranje[i + 6:j + i + 6]+"\n")
        if treniranje[i:i+7]=="Howard:":
            j = treniranje[i + 7:].find("\n")
            f_Howard.write(treniranje[i + 7:j + i + 7]+"\n")
    return
klasificiranje(treniranje)
testiranje = open("KorpusZaTestiranje.txt", "r",encoding="utf8").read()
def klasificiranjeT(testiranje):
    file_Leonard= open("LeonardTEST.txt","w+")
    file_Penny= open("PennyTEST.txt","w+")
    file_Sheldon= open("SheldonTEST.txt","w+")
    file_Howard=open("HowardTEST.txt","w+")
    for i in range(len(testiranje)):
        if testiranje[i:i+8]=="Leonard:":
            j=testiranje[i+8:].find("\n")
            file_Leonard.write(testiranje[i+8:j+i+8]+"\n")
        if testiranje[i:i+8]=="Sheldon:":
            j = testiranje[i + 8:].find("\n")
            file_Sheldon.write(testiranje[i + 8:j + i + 8]+"\n")
        if testiranje[i:i+6]=="Penny:":
            j = testiranje[i + 6:].find("\n")
            file_Penny.write(testiranje[i + 6:j + i + 6]+"\n")
        if testiranje[i:i+7]=="Howard:":
            j = testiranje[i + 7:].find("\n")
            file_Howard.write(testiranje[i + 7:j + i + 7]+"\n")
    return
klasificiranjeT(testiranje)
Leonard = open("Leonard.txt", "r").read()
Penny= open("Penny.txt", "r").read()
Sheldon = open("Sheldon.txt", "r").read()
Howard = open("Howard.txt", "r").read()
def BrDok(klasa):
    return klasa.count('\n')
def VjerojatnostKlase(klasa):
    return BrDok(klasa)/(BrDok(Penny) +BrDok(Howard) + BrDok(Leonard) + BrDok(Sheldon))
vj_Sheldon = VjerojatnostKlase(Sheldon)
vj_Penny = VjerojatnostKlase(Penny)
vj_Leonard = VjerojatnostKlase(Leonard)
vj_Howard = VjerojatnostKlase(Howard)
import re
def BrojRijeci(klasa):
    return len(re.split(r'[();.,\!\?\s]\s*', klasa))
br_rijeci_Howard=BrojRijeci(Howard)
br_rijeci_Leonard=BrojRijeci(Leonard)
br_rijeci_Penny=BrojRijeci(Penny)
br_rijeci_Sheldon=BrojRijeci(Sheldon)
def RadiListu(klasa):
    return re.split(r'[();,.\!\?\s]\s*', klasa)[1:-1]
def RadiRjecnik(lista_rijeci):
    rjecnik = dict()
    for rijec in lista_rijeci:
        if rijec.lower() not in rjecnik.keys():
            rjecnik[rijec.lower()] = 1
        else:
            rjecnik[rijec.lower()] += 1
    rjecnik = {k: v for k, v in sorted(rjecnik.items(), key=lambda item: item[1])}
    return rjecnik
rjecnik_Howard = RadiRjecnik(RadiListu(Howard))
rjecnik_Penny = RadiRjecnik(RadiListu(Penny))
rjecnik_Sheldon = RadiRjecnik(RadiListu(Sheldon))
rjecnik_Leonard = RadiRjecnik(RadiListu(Leonard))
V = len({**rjecnik_Sheldon, **rjecnik_Penny, **rjecnik_Howard, **rjecnik_Leonard})
Leonard2 = open("LeonardTEST.txt", "r").read()
Penny2 = open("PennyTEST.txt", "r").read()
Sheldon2 = open("SheldonTEST.txt", "r").read()
Howard2 = open("HowardTEST.txt", "r").read()

HowardT = re.split('\n', Howard2)
PennyT = re.split('\n', Penny2)
SheldonT = re.split('\n', Sheldon2)
LeonardT = re.split('\n', Leonard2)

def RacunajVjerojatnost(klasaT, vjP, vjL, vjH, vjS, rjecnik_Leonard,
                        rjecnik_Howard, rjecnik_Sheldon, rjecnik_Penny, V,
                        br_rijeci_Leonard, br_rijeci_Penny, br_rijeci_Howard, br_rijeci_Sheldon):
    lista = []
    for rec in klasaT:
        vjPP = vjP
        vjLL = vjL
        vjHH = vjH
        vjSS = vjS
        lista_rijeci = re.split(r'[();,.\!\?\s]\s*', rec)[1:-1]
        for rijec in lista_rijeci:
            if rijec in rjecnik_Penny.keys():
                vjPP = vjPP * ((rjecnik_Penny[rijec] + 1) / (br_rijeci_Penny + V))
            else:
                vjPP = vjPP * ((1) / (br_rijeci_Penny + V))

            if rijec in rjecnik_Leonard.keys():
                vjLL = vjLL * ((rjecnik_Leonard[rijec] + 1) / (br_rijeci_Leonard + V))
            else:
                vjLL = vjLL * ((1) / (br_rijeci_Leonard + V))

            if rijec in rjecnik_Howard.keys():
                vjHH = vjHH * ((rjecnik_Howard[rijec] + 1) / (br_rijeci_Howard + V))
            else:
                vjHH = vjHH * ((1) / (br_rijeci_Howard + V))

            if rijec in rjecnik_Sheldon.keys():
                vjSS = vjSS * ((rjecnik_Sheldon[rijec] + 1) / (br_rijeci_Sheldon + V))
            else:
                vjSS = vjSS * ((1) / (br_rijeci_Sheldon + V))
        lista.append(RacunajMax([vjPP, vjLL, vjHH, vjSS]))
    return lista
def RacunajMax(lista):
    vjP = lista[0]
    vjL = lista[1]
    vjH = lista[2]
    vjS = lista[3]

    if max(vjP, vjL, vjH, vjS) == vjP:
        kraj = "Penny"
    elif max(vjP, vjL, vjH, vjS) == vjL:
        kraj = "Leonard"
    elif max(vjP, vjL, vjH, vjS) == vjS:
        kraj = "Sheldon"
    elif max(vjP, vjL, vjH, vjS) == vjH:
        kraj = "Howard"
    return kraj
klasifikacijaTHoward = RacunajVjerojatnost(HowardT, vj_Penny, vj_Leonard, vj_Howard, vj_Sheldon, rjecnik_Leonard,
                            rjecnik_Howard, rjecnik_Sheldon, rjecnik_Penny, V,
                            br_rijeci_Leonard, br_rijeci_Penny, br_rijeci_Howard, br_rijeci_Sheldon)

klasifikacijaTLeonard = RacunajVjerojatnost(LeonardT, vj_Penny, vj_Leonard, vj_Howard, vj_Sheldon, rjecnik_Leonard,
                            rjecnik_Howard, rjecnik_Sheldon, rjecnik_Penny, V,
                            br_rijeci_Leonard, br_rijeci_Penny, br_rijeci_Howard, br_rijeci_Sheldon)

klasifikacijaTPenny = RacunajVjerojatnost(PennyT, vj_Penny, vj_Leonard, vj_Howard, vj_Sheldon, rjecnik_Leonard,
                            rjecnik_Howard, rjecnik_Sheldon, rjecnik_Penny, V,
                            br_rijeci_Leonard, br_rijeci_Penny, br_rijeci_Howard, br_rijeci_Sheldon)
klasifikacijaTSheldon = RacunajVjerojatnost(SheldonT, vj_Penny, vj_Leonard, vj_Howard, vj_Sheldon, rjecnik_Leonard,
                            rjecnik_Howard, rjecnik_Sheldon, rjecnik_Penny, V,
                            br_rijeci_Leonard, br_rijeci_Penny, br_rijeci_Howard, br_rijeci_Sheldon)
def Broji(lista):
    P = 0
    L = 0
    H = 0
    S = 0
    for el in lista:
        if(el == "Penny"):
            P+=1
        if(el == "Leonard"):
            L+=1
        if(el == "Howard"):
            H+=1
        if(el == "Sheldon"):
            S+=1
    ukupno = P+L+H+S
    return [P,L,H,S,ukupno]
petorkaP = Broji(klasifikacijaTPenny)
petorkaL = Broji(klasifikacijaTLeonard)
petorkaH = Broji(klasifikacijaTHoward)
petorkaS = Broji(klasifikacijaTSheldon)
